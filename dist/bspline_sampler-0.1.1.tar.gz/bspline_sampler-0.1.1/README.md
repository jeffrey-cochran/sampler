# Sampler
A simple tool for sampling B-spline coefficients distributed as Gaussian Random Fields, subject to constraints.