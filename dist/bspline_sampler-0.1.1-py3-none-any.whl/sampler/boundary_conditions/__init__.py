from .base import BoundaryCondition, BoundaryConditions, DirichletBC, NeumannBC
from .unit_square import UnitSquareBoundaryConditions